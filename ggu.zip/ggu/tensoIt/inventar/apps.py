from django.apps import AppConfig


class InventarConfig(AppConfig):
    name = 'inventar'
    verbose_name = '2.Компьютеры и техника'
