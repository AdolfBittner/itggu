from django.apps import AppConfig


class KadryConfig(AppConfig):
    name = 'kadry'
    verbose_name = '1.Кадры'
